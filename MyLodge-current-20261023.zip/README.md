# MyLodge Platform

2026-10-23 마이롯지 개편 시안입니다. 메인·3D 인트로와 국내 파크·치앙마이·오너 안내를 포함합니다. 기존 카테고리와 사이드페이지 한·영 전환을 유지했습니다.

- 기준 브랜치: `codex/mylodge-reconcept-20261023`
- Hojiakbar(John)의 별도 메인페이지 브랜치는 합치지 않았습니다. 추후 담당자 간 검토 후 통합합니다.
- 현재는 정적 콘텐츠 시안입니다. 인증·예약·결제·회원 SWAP의 실제 서버 기능은 포함하지 않습니다.
- 서비스·가격·분납·소유 및 상속 조건은 확정 전으로 표시했습니다.

## 실행

Node.js 20 이상을 사용합니다. 외부 npm 의존성은 없습니다.

```sh
npm run build
npm start
```

미리보기: `http://127.0.0.1:4173` (`PORT` 변경 가능). Vercel은 `dist/`만 공개합니다. `scripts/public-files.json`은 공개 파일과 SHA256을 명시하며, 파일이 바뀌면 목록의 크기·해시도 갱신해야 합니다.

## English handoff

This static concept includes the homepage, villa-to-coin 3D intro, Korea parks, Chiang Mai and owner guide. John’s separate homepage branch has **not** been merged. Review and agree on integration before merging it. Member authentication, booking, payment and SWAP backends are outside this release. Commercial and legal conditions remain pending confirmation.

Run `npm run build` then `npm start` with Node.js 20+. There are no npm dependencies. Only the explicit public allowlist is copied into `dist/`; development notes and this README are excluded. Vendored Three.js retains its MIT licence in `vendor/THREE-LICENSE.txt`.
