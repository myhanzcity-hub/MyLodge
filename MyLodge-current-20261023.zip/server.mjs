import http from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,relative,dirname,extname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'dist');
const port=Number(process.env.PORT||4173);
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.webp':'image/webp','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8','.woff':'font/woff','.woff2':'font/woff2','.mp4':'video/mp4','.mp3':'audio/mpeg'};
const legacy={'/domestic-villas.html':'/parks/domestic-villas.html','/business-valley.html':'/parks/business-valley.html','/owners.html':'/parks/owners.html'};
const server=http.createServer(async(req,res)=>{
 try{
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405,{'Allow':'GET, HEAD'});return res.end('Method not allowed');}
  const url=new URL(req.url,'http://localhost');
  if(legacy[url.pathname]){res.writeHead(307,{'Location':legacy[url.pathname]+url.search});return res.end();}
  const path=decodeURIComponent(url.pathname),parts=path.split('/');
  if(parts.some(p=>p==='..'||p.startsWith('.'))||path.includes('\\')||path.includes('\0')){res.writeHead(403);return res.end('Forbidden');}
  let file=resolve(root,'.'+path);const rel=relative(root,file);
  if(rel.startsWith('..'+sep)||rel==='..'){res.writeHead(403);return res.end('Forbidden');}
  if((await stat(file)).isDirectory())file=resolve(file,'index.html');
  const bytes=await readFile(file);res.writeHead(200,{'Content-Type':types[extname(file).toLowerCase()]||'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});res.end(req.method==='HEAD'?undefined:bytes);
 }catch(error){res.writeHead(error.code==='ENOENT'?404:400,{'Content-Type':'text/plain; charset=utf-8'});res.end(error.code==='ENOENT'?'Not found':'Bad request');}
});
server.listen(port,'127.0.0.1',()=>console.log(`MyLodge preview http://127.0.0.1:${port}`));
