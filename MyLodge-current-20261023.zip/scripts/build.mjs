import {readFile,mkdir,copyFile,rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {dirname,resolve,relative,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const output=resolve(root,'dist');
const manifest=JSON.parse(await readFile(resolve(root,'scripts/public-files.json'),'utf8'));
if(output!==resolve(root,'dist')||relative(root,output)!=='dist')throw Error('Invalid output directory');
const seen=new Set();
for(const entry of manifest.files){
 if(typeof entry.path!=='string'||entry.path.startsWith('/')||entry.path.includes('\\')||entry.path.split('/').some(part=>!part||part==='..'||part==='.'||part.startsWith('.'))||seen.has(entry.path))throw Error('Invalid or duplicate public path: '+entry.path);
 seen.add(entry.path);
 const source=resolve(root,entry.path),rel=relative(root,source);
 if(rel.startsWith('..'+sep)||rel==='..'||rel==='')throw Error('Public path escapes project');
 const bytes=await readFile(source);
 if(bytes.length!==entry.bytes||createHash('sha256').update(bytes).digest('hex')!==entry.sha256)throw Error('Public file changed: '+entry.path);
}
await rm(output,{recursive:true,force:true});
for(const entry of manifest.files){
 const target=resolve(output,entry.path);
 await mkdir(dirname(target),{recursive:true});
 await copyFile(resolve(root,entry.path),target);
}
console.log(`Built ${manifest.files.length} public files in dist/`);
